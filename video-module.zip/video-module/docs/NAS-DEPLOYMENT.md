# NAS Deployment — the filesystem storage mode

The normal production shape: **media bytes on a mounted share, catalogue and segment index in the
database.** This is what you want whenever durable disk exists, and it is simpler in every respect
than the database mode this project runs on a free tier.

Companion files:
- [`../config/application-video-nas.yml`](../config/application-video-nas.yml) — annotated config
- [`../db/schema-nas.sql`](../db/schema-nas.sql) — schema without `video_assets`
- [`diagrams.puml`](diagrams.puml) → `deployment-nas` block

---

## 1. Why this mode is the default

| | NAS / filesystem | Database |
|---|---|---|
| Media bytes | files on a share | `BYTEA` rows |
| Capacity | the share's capacity | a database budget you must police |
| Serving a segment | `sendfile` from disk | a SQL read |
| Serving a byte range | seeked channel read | SQL `substring` |
| Backup | file-level, incremental | inside your database dump |
| Peak memory during ingest | none — nothing is ingested | one segment (with the drain) |
| Database size for 100 recordings | a few MB | **tens of GB** |

Database mode exists for one reason: a host with no persistent volume, where the container filesystem
is wiped on every redeploy and recordings written to it are silently destroyed. If you have a volume,
you do not want that trade.

---

## 2. What disappears in this mode

Worth knowing so you don't go looking for machinery that isn't running.

**The segment drain does not run.** `VideoSegmentDrainer` exists to move segments off disk into the
database *while* FFmpeg is still writing, because holding a whole ladder in memory to insert it at the
end costs ~2 GB for an hour-long recording. On a NAS, FFmpeg writes segments to their final location
and they simply stay there. Nothing to drain, nothing to ingest, no peak.

**There is no storage budget.** `video.database.max-total-bytes` and friends do not apply. Capacity
planning is ordinary disk capacity planning ([§6](#6-capacity-planning)).

**The original upload is always kept.** `video.database.keep-source=false` exists because storing the
source doubles database usage. On a share it costs disk you have, and it is what makes *Re-process*
possible — so it stays.

**`video_assets` is unused.** [`schema-nas.sql`](../db/schema-nas.sql) omits it entirely.

---

## 3. Mounting the share

The application needs a path it can **read, write, create directories in, and delete from**. It
creates one folder per recording, named by UUID.

### Linux — NFS

```bash
# /etc/fstab
nas01:/export/meetings/videos  /mnt/nas/meetings/videos  nfs4  \
    rw,hard,timeo=600,retrans=2,noatime,_netdev  0 0
```

- **`hard`, not `soft`.** A soft mount returns an I/O error when the NAS is briefly unreachable,
  which surfaces as a corrupt segment mid-playback. A hard mount blocks and retries — a stall is
  recoverable, a truncated write is not.
- **`noatime`** — segment serving is read-heavy; there is no reason to write an access timestamp per
  read.
- **`_netdev`** so the mount waits for the network at boot.

### Linux — SMB/CIFS

```bash
//nas01/media/meetings/videos  /mnt/nas/meetings/videos  cifs  \
    credentials=/etc/nas.cred,uid=1000,gid=1000,file_mode=0644,dir_mode=0755,vers=3.1.1,_netdev  0 0
```

`uid`/`gid` must be the account the application runs as — CIFS does not map permissions the way NFS
does, so ownership is decided at mount time.

### Windows

A UNC path works directly:

```
VIDEO_NAS_PATH=\\nas01\media\meetings\videos
```

The service account needs Modify on the share. If running as a Windows service, note that mapped
drive letters are **per-session** and will not exist — always use the UNC path.

### Container

```yaml
# docker-compose
services:
  api:
    volumes:
      - /mnt/nas/meetings/videos:/media/videos
    environment:
      VIDEO_NAS_PATH: /media/videos
      VIDEO_REQUIRE_NAS: "true"
```

Kubernetes: a `PersistentVolumeClaim` with `ReadWriteMany` if more than one replica serves media.
`ReadWriteOnce` will not do — every replica reads every recording.

---

## 4. Configuration

Merge [`application-video-nas.yml`](../config/application-video-nas.yml). The three that matter:

```yaml
video:
  storage-mode: filesystem
  nas-path: /mnt/nas/meetings/videos
  require-nas: true          # ← the important one
```

**`require-nas: true` in every real environment.** With it false, a missing mount falls back to an
ordinary directory on the host: uploads appear to succeed and are destroyed on the next restart. That
is a silent, unrecoverable data-loss path. Refusing to start is loud and fixable.

The startup check writes and deletes a probe file — a mount that exists but is read-only is otherwise
only discovered when someone uploads.

### Tuning for a real server

| Setting | Constrained default | NAS server | Why |
|---|---|---|---|
| `hls.parallel-rungs` | `false` | **`true`** | One decode feeding N encoders; much faster. Off only where peak memory is the binding constraint |
| `tools.threads` | `1` | **`0`** | 0 = one thread per core. Correct on a dedicated box |
| `tools.niceness` | `15` | `0`, or keep if the API shares the host | Stops an encode starving the health check |
| `tools.workers` | `1` | **`2`–`4`** | Concurrent transcodes; size to cores |
| `max-upload-bytes` | 2 GiB | raise freely | The limit is disk, not a row |

---

## 5. On-disk layout

```
/mnt/nas/meetings/videos/
└── 0b4bbc56-55a6-4f86-9a0e-ab064b5c80a4/     ← the video's UUID
    ├── source.mp4          the original upload — kept, so Re-process works
    ├── poster.jpg          catalogue thumbnail
    ├── sprite.jpg          seek-preview filmstrip (one grid image)
    ├── transcript.vtt      captions, if uploaded
    └── hls/
        ├── master.m3u8     variant list
        ├── 1080p/index.m3u8 + seg_00000.ts …
        ├── 720p/…
        ├── 480p/…
        └── 360p/…
```

The database stores **relative** paths (`hls/720p/seg_00042.ts`), never absolute ones. So moving the
share, renaming the mount point, or restoring to a different path requires no data migration — only
`VIDEO_NAS_PATH`.

**Nothing outside a recording's own folder is reachable.** Every client-supplied relative path goes
through one resolver that normalises separators and rejects anything escaping the base. That is the
single path-traversal boundary; no other code is permitted to build a media path.

---

## 6. Capacity planning

Output is roughly **2–3× the source** across a four-rung ladder. Measured here: a 13.2 MB 720p source
produced 26.1 MB across three rungs.

| Source | Ladder | Segments + poster/sprite | With the original |
|---|---|---|---|
| 100 MB (10 min, 720p) | 1080/720/480/360 | ~250 MB | ~350 MB |
| 500 MB (45 min, 1080p) | full | ~1.3 GB | ~1.8 GB |
| 2 GB (3 h, 1080p) | full | ~5 GB | ~7 GB |

**Rule of thumb: budget 3.5× your expected upload volume.** Trim by dropping rungs (`VIDEO_LADDER`)
or by not keeping originals — though the latter costs *Re-process* and the original-quality download.

Inode count matters on some filers: a 45-minute recording at four rungs is roughly **1,800 files**. A
thousand such recordings is nearly two million inodes. Check the filer's limit, not just its bytes.

---

## 7. Backup and restore

The database and the share must be backed up **together** — a catalogue row whose media is missing,
or media with no row, are both useless.

```bash
# 1. Database
pg_dump "$DATABASE_URL" > meetings.sql

# 2. Media — hardlink-incremental, so unchanged recordings cost nothing
rsync -a --delete --link-dest=/backup/videos.prev \
      /mnt/nas/meetings/videos/ /backup/videos.$(date +%F)/
```

Media files are **immutable once written**, so incremental backup is genuinely cheap: only new
recordings transfer.

**Restore order: database first, then media.** The application marks recordings whose media is
missing as `FAILED` at boot ([`flagMissingMedia`](../backend/service/VideoLibraryService.java)) — so
restoring in the other order can flag everything before the files arrive. If that happens, restore the
media and *Re-process*, or reset the status directly.

---

## 8. Operating notes

**Serving is offset-independent.** A range request reads via a seeked channel, so byte 900,000,000 of
a 2 GB file costs the same as byte 0. Nothing is ever buffered whole.

**Segments are served `immutable, max-age=1y`.** They never change, so a CDN or reverse proxy in front
of the share is a straightforward win. Manifests carry an expiring ticket and are `no-store` — do not
cache those.

**Transcoding is the only heavy thing.** If the API and encoding share a host, keep
`tools.niceness` non-zero. The clean separation is a dedicated transcode worker pointed at the same
share — which is what `VideoProcessingWorker` and its own pool are already factored for.

**A stranded `PROCESSING` row** means the process died mid-transcode. It is marked `FAILED` at boot
rather than retried, because the likeliest cause is resource exhaustion and retrying would loop the
crash. *Re-process* is one click.

---

## 9. Stripping database mode entirely

If you will never need it, these can go — the module still compiles and behaves identically:

| Remove | Notes |
|---|---|
| `model/VideoAsset.java` | |
| `repository/VideoAssetRepository.java` | |
| `model/VideoStorageMode.java` | or keep the enum with only `FILESYSTEM` |
| `service/VideoSegmentDrainer.java` | drain is database-mode only |
| `VideoProperties.Database` (inner class) | and its `application.yml` block |
| `video_assets` from the schema | already absent from `schema-nas.sql` |

Then simplify `VideoMediaStore` so every method delegates straight to `VideoStorageService` — the
`inDatabase(video)` branch in each becomes dead.

**I would not bother.** The abstraction costs one branch per method and buys the option of running the
same code on a host with no volume. Keeping it also means the two modes stay per-video, so a later
migration is a re-process rather than a rewrite.
