# Video module — shareable extract

Everything the on-demand video feature consists of, lifted out of the host application so it can be
read, reviewed and ported without the surrounding project.

**Read [`../VIDEO_MODULE_SPEC.md`](../docs/VIDEO_MODULE_SPEC.md) first** — it explains the architecture,
the flows and the constraints. This file covers only what you need to *drop the code in*.

---

## What is here

| Path | Contents |
|---|---|
| `backend/` | 29 Java files — controllers, services, entities, repositories |
| `frontend/` | 5 TypeScript files — player, pages, services |
| `config/application-video.yml` | annotated config — **database** storage mode (no persistent disk) |
| `config/application-video-nas.yml` | annotated config — **NAS/filesystem** mode, the normal shape |
| `db/schema.sql` | standalone PostgreSQL DDL (both modes) |
| `db/schema-nas.sql` | the same, without `video_assets` — NAS mode only |
| `docs/NAS-DEPLOYMENT.md` | mounting, permissions, capacity, backup, tuning for a real server |
| `docs/diagrams.puml` | 11 PlantUML diagrams |

**Deploying to a real server with a volume or NAS?** Start with
[`docs/NAS-DEPLOYMENT.md`](docs/NAS-DEPLOYMENT.md) and the two `-nas` files. The other config and
schema target a host with *no* durable disk, which is a harder and less common problem.

Files are copied **verbatim**, comments included. The comments carry the reasoning behind the
non-obvious decisions; they are the most useful part to read first.

---

## Dependencies

**Runtime**

- FFmpeg **and** FFprobe on `PATH`. Without them the module still works — uploads are served
  progressively over HTTP `Range` instead of as a ladder — but there is no adaptive playback.
- PostgreSQL, or any RDBMS with a binary column type and binary `substring`. Database storage mode
  needs both; filesystem mode needs neither.
- A writable directory for transcode scratch space — **required in both storage modes**, because
  FFmpeg reads and writes real files.

**Backend libraries** — Spring Boot 3 (web, data-jpa, security, validation), JJWT, Jackson,
PostgreSQL driver. Java 21 (uses records and pattern-matching `instanceof`).

**Frontend** — `hls.js` (Apache-2.0), Angular 20+ for signals. No other runtime dependency.

---

## Integration points

These five touch the host application. Everything else is self-contained.

**1. Package names.** Files declare `com.agmsentinel.*`. Rename to your own root.

**2. Authentication.** The module needs two things:

```java
// who is asking — used for uploadedBy, comment authors, like ownership, ticket subjects
SecurityContextHolder.getContext().getAuthentication().getName()

// and whether they moderate — used for "delete any comment"
authentication.getAuthorities()   // ROLE_MODERATOR / ROLE_ADMIN
```

Usernames are stored as plain text in `video_likes.username` and `video_comments.author`. There is
no foreign key to a users table — deliberately, so the module does not constrain your user model.

**3. Playback tickets.** `PlaybackTicketService` delegates to the host's `JwtService` for signing.
Substitute any signed, expiring, single-resource token. The requirements are: scoped to one video id,
short-lived, and distinguishable from a session token so it can never be used as a login.

**4. Security rules.** Media routes must be reachable **without** an `Authorization` header, because
the browser's media stack cannot send one. They are authorised inside the controller by the ticket.

```java
.requestMatchers(HttpMethod.GET,
        "/api/videos/*/master.m3u8",
        "/api/videos/*/r/**",
        "/api/videos/*/raw",
        "/api/videos/*/poster.jpg",
        "/api/videos/*/sprite.jpg",
        "/api/videos/*/transcript.vtt",
        "/api/videos/*/download").permitAll()
.requestMatchers("/api/videos/**").authenticated()
.requestMatchers("/api/admin/**").hasAnyRole("MODERATOR", "ADMIN")
```

**5. Async.** `VideoAsyncConfig` defines the transcode pool. `@EnableAsync` must be present
somewhere in the application.

---

## Bringing it up

Pick the pair that matches your host. **If you have a volume or a NAS, use the `-nas` files** — that
is the simpler deployment and the one most teams want.

```bash
# --- NAS / filesystem: media on a share, catalogue in the database ---
psql "$DATABASE_URL" -f db/schema-nas.sql
cat config/application-video-nas.yml        # set nas-path, require-nas: true

# --- OR database mode: no durable disk anywhere on the host ---
psql "$DATABASE_URL" -f db/schema.sql
cat config/application-video.yml
```

```bash
# Backend — copy under your source root, then rename packages
cp -r backend/* src/main/java/<your>/<package>/

# Frontend
cp -r frontend/* src/app/
npm install hls.js
```

Then, in order:

1. Upload a small MP4 → expect `status=PROCESSING`, then `READY`.
2. Check `video_renditions` and `video_segments` are populated — that is the segment index.
3. Play it. In the network panel you should see `master.m3u8`, then `index.m3u8`, then a **steady
   trickle of `seg_NNNNN.ts`** rather than one large request. That trickle *is* the feature.
4. Seek to the far end. Expect one segment request, not a re-download.

---

## Verifying the properties that matter

| Property | How to check |
|---|---|
| Playback never downloads the file | Network panel shows one ~6 s segment at a time |
| Seeking costs one segment | Seek to the end; one new request |
| Adaptive switching | Throttle the network; the level drops at a segment boundary |
| Transcode cost is length-independent | Watch RSS during a long upload — it should stay flat |
| Range serving is offset-independent | `curl -r 900000000-900004095` on a large progressive file |
| Path traversal is blocked | Request `../../etc/passwd` as a segment name → 403 |

---

## Sizing

Segment output is roughly **2× the source** across three rungs (measured: a 13.2 MB 720p source
produced 26.1 MB). A 40-minute recording at three rungs is on the order of 1.5 GB — which is why
database storage mode enforces a total budget and is documented as suiting *modest* libraries.

For a constrained host, read [§13 of the spec](../docs/VIDEO_MODULE_SPEC.md#13-operating-within-a-small-container)
before deploying. Those constraints are not theoretical; each one is there because of a specific
failure.

---

## Licensing

The module's own code carries the host project's licence. Two external dependencies matter:

- **hls.js** — Apache-2.0.
- **FFmpeg** — LGPL, or **GPL** when built with `libx264` (as this module's H.264 encoding requires).
  Invoking FFmpeg as a **subprocess** is not linking, so it does not impose GPL terms on your code.
  Shipping a container image that *bundles* a GPL FFmpeg build means that image redistributes GPL
  software — a different position, normal and fine, but worth being deliberate about.
