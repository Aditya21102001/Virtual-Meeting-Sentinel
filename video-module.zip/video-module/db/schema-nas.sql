-- ==========================================================================
-- Video module schema — NAS / filesystem deployment (PostgreSQL).
--
-- Media bytes live on a mounted share; this database holds only the catalogue,
-- the ladder, the SEGMENT INDEX and engagement. Nothing here grows with the
-- size of a recording — a three-hour upload adds the same handful of rows a
-- three-minute one does.
--
-- Differs from schema.sql by one omission: there is no `video_assets` table.
-- That table exists only for storage-mode=database, where it holds media as
-- BYTEA because the host has no durable disk. Add it later if you ever need
-- that mode; the application decides per video which backend to read from.
--
-- Requires pgcrypto (or PG13+) for gen_random_uuid().
-- ==========================================================================

CREATE TABLE IF NOT EXISTS videos (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title                   TEXT        NOT NULL,
    description             TEXT,
    original_filename       TEXT        NOT NULL,
    content_type            TEXT,
    size_bytes              BIGINT      NOT NULL DEFAULT 0,
    storage_dir             TEXT        NOT NULL,          -- folder under the NAS root
    source_rel              TEXT,                          -- original file, relative to storage_dir
    master_playlist_rel     TEXT,                          -- hls/master.m3u8
    poster_rel              TEXT,
    sprite_rel              TEXT,                          -- seek-preview filmstrip
    transcript_rel          TEXT,                          -- uploaded WebVTT captions
    sprite_interval_seconds INT,
    sprite_columns          INT,
    sprite_tile_width       INT,
    sprite_tile_height      INT,
    duration_seconds        DOUBLE PRECISION,
    width                   INT,
    height                  INT,
    frame_rate              DOUBLE PRECISION,
    has_audio               BOOLEAN     NOT NULL DEFAULT TRUE,
    status                  VARCHAR(20) NOT NULL DEFAULT 'UPLOADED',  -- UPLOADED|PROCESSING|READY|FAILED
    delivery_mode           VARCHAR(20) NOT NULL DEFAULT 'HLS',       -- HLS|PROGRESSIVE
    -- Per-video, so changing the server default never strands existing recordings.
    storage_mode            VARCHAR(20) NOT NULL DEFAULT 'FILESYSTEM', -- FILESYSTEM|DATABASE
    progress_percent        INT         NOT NULL DEFAULT 0,
    error_message           TEXT,
    segment_seconds         INT,
    uploaded_by             TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS videos_status_idx  ON videos (status);
CREATE INDEX IF NOT EXISTS videos_created_idx ON videos (created_at);

-- One rung of the adaptive ladder (1080p / 720p / …), each with its own media playlist.
CREATE TABLE IF NOT EXISTS video_renditions (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id           UUID        NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    name               VARCHAR(32) NOT NULL,
    width              INT         NOT NULL DEFAULT 0,
    height             INT         NOT NULL DEFAULT 0,
    video_bitrate_kbps INT         NOT NULL DEFAULT 0,
    audio_bitrate_kbps INT         NOT NULL DEFAULT 0,
    playlist_rel       TEXT        NOT NULL,
    segment_count      INT         NOT NULL DEFAULT 0,
    total_bytes        BIGINT      NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS video_renditions_video_idx ON video_renditions (video_id);

-- The segment index: one row per ~6s slice. start_seconds is what turns
-- "seek to 21:30" into "fetch segment 215" instead of streaming from zero.
CREATE TABLE IF NOT EXISTS video_segments (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rendition_id     UUID             NOT NULL REFERENCES video_renditions (id) ON DELETE CASCADE,
    seq              INT              NOT NULL,
    filename         TEXT             NOT NULL,
    duration_seconds DOUBLE PRECISION NOT NULL DEFAULT 0,
    start_seconds    DOUBLE PRECISION NOT NULL DEFAULT 0,
    byte_size        BIGINT           NOT NULL DEFAULT 0,
    CONSTRAINT video_segments_unique_seq UNIQUE (rendition_id, seq)
);

CREATE INDEX IF NOT EXISTS video_segments_rendition_seq_idx
    ON video_segments (rendition_id, seq);


-- Engagement on recordings. A row per like rather than a counter column on `videos`: a counter
-- cannot answer "have I liked this", which is the half the button needs, and two simultaneous likes
-- would race on an increment. The unique constraint makes double-liking impossible at the database
-- rather than trusting the UI to prevent it.
-- ON DELETE CASCADE, matching video_assets. The application deletes these explicitly
-- (VideoEngagementService.deleteAllFor) because the entity holds a plain video_id rather than a
-- relation — loading a like must not drag a whole Video graph with it. That makes the cascade a
-- backstop rather than the mechanism: it is what stops a deletion by any other route leaving likes
-- and comments pointing at a recording that no longer exists.
CREATE TABLE IF NOT EXISTS video_likes (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID        NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    username   TEXT        NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT video_likes_unique_member UNIQUE (video_id, username)
);

CREATE INDEX IF NOT EXISTS video_likes_video_idx ON video_likes (video_id);

-- Flat, not threaded: a meeting recording attracts questions and corrections, not conversation
-- trees. `at_seconds` lets a comment point at a moment, which the UI turns into a seek.
CREATE TABLE IF NOT EXISTS video_comments (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID        NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    author     TEXT        NOT NULL,   -- taken from the principal, never from the request body
    body       TEXT        NOT NULL,
    at_seconds DOUBLE PRECISION,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    edited_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS video_comments_video_idx ON video_comments (video_id, created_at);
