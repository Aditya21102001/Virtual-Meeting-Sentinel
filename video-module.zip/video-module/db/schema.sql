-- ==========================================================================
-- Video module schema — PostgreSQL.
--
-- Self-contained: no dependency on the rest of the application's schema. The only
-- outside reference is the username/author text columns, which hold whatever your
-- authentication layer calls a principal.
--
-- Requires pgcrypto (or PG13+) for gen_random_uuid().
-- ==========================================================================

CREATE TABLE IF NOT EXISTS videos (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title                   TEXT        NOT NULL,
    description             TEXT,
    original_filename       TEXT        NOT NULL,
    content_type            TEXT,
    size_bytes              BIGINT      NOT NULL DEFAULT 0,
    storage_dir             TEXT        NOT NULL,          -- folder under the NAS root
    source_rel              TEXT,                          -- original file, relative to storage_dir
    master_playlist_rel     TEXT,                          -- hls/master.m3u8
    poster_rel              TEXT,
    sprite_rel              TEXT,                          -- seek-preview filmstrip
    transcript_rel          TEXT,                          -- uploaded WebVTT captions
    sprite_interval_seconds INT,
    sprite_columns          INT,
    sprite_tile_width       INT,
    sprite_tile_height      INT,
    duration_seconds        DOUBLE PRECISION,
    width                   INT,
    height                  INT,
    frame_rate              DOUBLE PRECISION,
    has_audio               BOOLEAN     NOT NULL DEFAULT TRUE,
    status                  VARCHAR(20) NOT NULL DEFAULT 'UPLOADED',  -- UPLOADED|PROCESSING|READY|FAILED
    delivery_mode           VARCHAR(20) NOT NULL DEFAULT 'HLS',       -- HLS|PROGRESSIVE
    -- Per-video, so changing the server default never strands existing recordings.
    storage_mode            VARCHAR(20) NOT NULL DEFAULT 'FILESYSTEM', -- FILESYSTEM|DATABASE
    progress_percent        INT         NOT NULL DEFAULT 0,
    error_message           TEXT,
    segment_seconds         INT,
    uploaded_by             TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS videos_status_idx  ON videos (status);
CREATE INDEX IF NOT EXISTS videos_created_idx ON videos (created_at);

-- One rung of the adaptive ladder (1080p / 720p / …), each with its own media playlist.
CREATE TABLE IF NOT EXISTS video_renditions (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id           UUID        NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    name               VARCHAR(32) NOT NULL,
    width              INT         NOT NULL DEFAULT 0,
    height             INT         NOT NULL DEFAULT 0,
    video_bitrate_kbps INT         NOT NULL DEFAULT 0,
    audio_bitrate_kbps INT         NOT NULL DEFAULT 0,
    playlist_rel       TEXT        NOT NULL,
    segment_count      INT         NOT NULL DEFAULT 0,
    total_bytes        BIGINT      NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS video_renditions_video_idx ON video_renditions (video_id);

-- The segment index: one row per ~6s slice. start_seconds is what turns
-- "seek to 21:30" into "fetch segment 215" instead of streaming from zero.
CREATE TABLE IF NOT EXISTS video_segments (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rendition_id     UUID             NOT NULL REFERENCES video_renditions (id) ON DELETE CASCADE,
    seq              INT              NOT NULL,
    filename         TEXT             NOT NULL,
    duration_seconds DOUBLE PRECISION NOT NULL DEFAULT 0,
    start_seconds    DOUBLE PRECISION NOT NULL DEFAULT 0,
    byte_size        BIGINT           NOT NULL DEFAULT 0,
    CONSTRAINT video_segments_unique_seq UNIQUE (rendition_id, seq)
);

CREATE INDEX IF NOT EXISTS video_segments_rendition_seq_idx
    ON video_segments (rendition_id, seq);

-- Media bytes, for videos stored with storage_mode = 'DATABASE'. Used when the host has no
-- persistent volume: a container filesystem is wiped on redeploy, which destroys recordings
-- written to it. Addressed by (video_id, rel_path) — deliberately the same relative-path
-- addressing the filesystem layout uses ('hls/720p/seg_00042.ts', 'poster.jpg'), so both
-- backends answer the same question.
--
-- Kept in its own table rather than as a column on video_segments so the segment index stays
-- small: a seek lookup or a playlist listing must never drag segment payloads along with it.
CREATE TABLE IF NOT EXISTS video_assets (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id     UUID   NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    rel_path     TEXT   NOT NULL,       -- relative to the video's folder, forward slashes
    content_type TEXT,
    byte_size    BIGINT NOT NULL DEFAULT 0,
    data         BYTEA  NOT NULL,
    CONSTRAINT video_assets_unique_path UNIQUE (video_id, rel_path)
);

CREATE INDEX IF NOT EXISTS video_assets_video_idx ON video_assets (video_id);

-- Engagement on recordings. A row per like rather than a counter column on `videos`: a counter
-- cannot answer "have I liked this", which is the half the button needs, and two simultaneous likes
-- would race on an increment. The unique constraint makes double-liking impossible at the database
-- rather than trusting the UI to prevent it.
-- ON DELETE CASCADE, matching video_assets. The application deletes these explicitly
-- (VideoEngagementService.deleteAllFor) because the entity holds a plain video_id rather than a
-- relation — loading a like must not drag a whole Video graph with it. That makes the cascade a
-- backstop rather than the mechanism: it is what stops a deletion by any other route leaving likes
-- and comments pointing at a recording that no longer exists.
CREATE TABLE IF NOT EXISTS video_likes (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID        NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    username   TEXT        NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT video_likes_unique_member UNIQUE (video_id, username)
);

CREATE INDEX IF NOT EXISTS video_likes_video_idx ON video_likes (video_id);

-- Flat, not threaded: a meeting recording attracts questions and corrections, not conversation
-- trees. `at_seconds` lets a comment point at a moment, which the UI turns into a seek.
CREATE TABLE IF NOT EXISTS video_comments (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID        NOT NULL REFERENCES videos (id) ON DELETE CASCADE,
    author     TEXT        NOT NULL,   -- taken from the principal, never from the request body
    body       TEXT        NOT NULL,
    at_seconds DOUBLE PRECISION,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    edited_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS video_comments_video_idx ON video_comments (video_id, created_at);
